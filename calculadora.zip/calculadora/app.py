from flask import Flask, render_template_string

app = Flask(__name__)

html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artículos Educativos</title>
</head>
<body>
    <h5>La importancia de los nutrientes esenciales y hábitos de vida y alimenticios:</h5>
    <h6>Nutrientes esenciales:</h6>
    <ul>
        <li>Proteínas</li>
        <li>Grasas Saludables</li>
        <li>Vitaminas y minerales</li>
    </ul>
    <h6>En Hábitos De Vida:</h6>
    <ul>
        <li></li>
        <li></li>
        <li></li>
    </ul>
    <h4>Beneficios:</h4>
    <ul>
        <li>Regula la temperatura</li>
        <li>Piel hidratada (Más suave)</li>
        <li>Eliminar toxinas a través de la orina.</li>
        <li>Mejora de la digestión</li>
        <li>Cuida a los hermanitos riñones</li>
    </ul>
    <h3>¿Es esencial?:</h3>
    <p>Es importante para el cuerpo humano porque ayuda a regular la temperatura corporal lubricando las articulaciones, órganos, manteniendo la piel hidratada y ayudando a tener una buena digestión previene enfermedades como.</p>
    <p>Fuentes:</p>
    <ol>
        <li><a href="https://www.gob.mx/salud/articulos/la-importancia-de-una-buena-hidratacion">https://www.gob.mx/salud/articulos/la-importancia-de-una-buena-hidratacion</a></li>
        <li></li>
    </ol>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(html_content)

if __name__ == '__main__':
    app.run(debug=True)
